module.exports = {


  friendlyName: 'View entendi relacion',


  description: 'Display "Entendi relacion" page.',


  exits: {

    success: {
      viewTemplatePath: 'pages/entidad-relacion'
    }

  },


  fn: async function () {

    // Respond with view.
    return {};

  }


};
