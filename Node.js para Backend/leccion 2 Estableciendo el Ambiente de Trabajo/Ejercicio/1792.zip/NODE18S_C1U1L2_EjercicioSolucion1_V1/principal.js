var esNumero = require('./es-numero')

console.log(esNumero("uno"))
console.log(esNumero('uno'))
console.log(esNumero(`uno`))
console.log(esNumero(1))
console.log(esNumero(1.0))
console.log(esNumero(1.000000))
console.log(esNumero(01))
